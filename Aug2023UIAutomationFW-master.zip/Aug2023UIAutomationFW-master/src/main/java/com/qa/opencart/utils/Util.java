package com.qa.opencart.utils;

public class Util {
	
	int i = 10;

}
