package com.qa.opencart.tests;

public class LoginPageNegativeTest {

}
