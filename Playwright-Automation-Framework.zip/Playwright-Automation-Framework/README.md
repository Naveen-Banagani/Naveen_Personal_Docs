# ey-playwright-automation-framework 
This repo contains playwright scripts for end to end EY automation. 

# Pipeline
Scripts are executed in Azure Pipelines:
 [![Build Status](https://dev.azure.com/EY/EY/_apis/build/status/Testing/EY-Playwright-Automation-Framework?branchName=main)](https://dev.azure.com/DSNCallCenter/EY-DSN/_build/latest?definitionId=254&branchName=main)
