const {expect, Locator, Page} = require('@playwright/test');
 class D365LandingPage
 {

    constructor(page)
    {
        this.page = page;
    
        this.usernameField = page.locator('//input[@type="email"]');
        this.next = page.locator('//input[@type="submit"]');
        this.passwordField = page.locator('//input[@type="password"]');
        this.appsSearchBox = page.locator('//input[@type="text"]');
        this.contacts = page.locator('#sitemap-entity-Contact');        
        this.myActiveContacts = page.locator('//span[contains(text(),"My Active Contacts")]');
        this.allContacts = page.locator('//label[contains(text(),"All Contacts")]/parent::node()/parent::node()');
        this.fourthRowName = page.locator("//div[@class=\"ag-center-cols-container\"]/div[@row-index=\"3\"]/div[@col-id=\"fullname\"]//span");
        this.firstRowName = page.locator("//div[@class=\"ag-center-cols-container\"]/div[@row-index=\"0\"]/div[@col-id=\"fullname\"]//span");
        this.firstRowEmail = page.locator("//div[@class=\"ag-center-cols-container\"]/div[@row-index=\"0\"]/div[@col-id=\"emailaddress1\"]//span");
        this.firstRowCompany = page.locator("//div[@class=\"ag-center-cols-container\"]/div[@row-index=\"0\"]/div[@col-id=\"parentcustomerid\"]//span");
        this.firstRowPhone = page.locator("//div[@class=\"ag-center-cols-container\"]/div[@row-index=\"0\"]/div[@col-id=\"telephone1\"]//span");
        this.firstRowStatus = page.locator("//div[@class=\"ag-center-cols-container\"]/div[@row-index=\"0\"]/div[@col-id=\"statecode\"]//label");
        this.searchContactsField = page.locator("//input[@placeholder=\"Filter by keyword\"]");
        this.searchContactsArrow = page.locator("//button[@title=\"Start search\"]");
        this.appName = page.locator("//span[@data-id='appBreadCrumbText']");
    }

    async navigateToD365PortalPage(url)
    {
        await this.page.goto(url);
    }

    async login(username, password)
    {
        await this.usernameField.fill(username);
        await this.next.click();
        await this.passwordField.fill(password);
        await this.next.click();
        await this.next.click();
    }

    async clickSalesHub()
    {
        
        this.frame = this.page.frameLocator("iframe[title='AppLandingPage']");
        if (this.frame != null)
        {            
            await this.frame.locator("#AppDetailsSec_1_Item_15").click();
        }

        else throw new error("no such frame")
        
        expect(this.appName).toHaveText("Sales Hub");
    }

    async clickContacts()
    {
        await this.contacts.click();
    }

    async clickMyActiveContacts()
    {
        await this.myActiveContacts.click();
    }

    async clickAllContacts()
    {
        await this.allContacts.click();        
    }

    async searchContacts(name)
    {
        await this.fourthRowName;
        await this.searchContactsField.fill(name);
        //await this.searchContactsArrow.click();
        await this.page.keyboard.press('Enter');
    }

    async verifyResults(firstRowName, firstRowEmail, firstRowCompany, firstRowPhone, firstRowStatus)
    {
        expect(this.firstRowName).toHaveText(firstRowName);
        expect(this.firstRowEmail).toHaveText(firstRowEmail);
        expect(this.firstRowCompany).toHaveText(firstRowCompany);
        expect(this.firstRowPhone).toHaveText(firstRowPhone);
    }
 }
 module.exports = {D365LandingPage};