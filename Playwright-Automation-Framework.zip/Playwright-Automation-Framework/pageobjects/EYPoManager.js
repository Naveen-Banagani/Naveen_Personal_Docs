
const {EYLandingPage} = require('./EYLandingPage');
const {D365LandingPage} = require('./D365LandingPage');

class EYPoManager
{
    constructor(page)
    {
       this.page = page       
       this.EYLandingPage = new EYLandingPage(this.page);
       this.D365LandingPage = new D365LandingPage(this.page);
    }
    
    getEYLandingPage()
    {
        return this.EYLandingPage;
    } 

    getD365LandingPage()
    {
        return this.D365LandingPage;
    }    
}

module.exports = {EYPoManager};