const {test,expect} = require('@playwright/test');

test.use({
  ignoreHTTPSErrors: true,
  extraHTTPHeaders: {
    "Content-type": 'application.json; charset=UTF-8',
    "Accept": 'application.json; charset=UTF-8',
    }
});

test('Get list of universities in Ireland', async ({ request }) => {
  const response = await request.get('http://universities.hipolabs.com/search?country=Ireland', {
    });
  expect(response.ok()).toBeTruthy();
  expect(response.status()).toBe(200);

  expect(await response.json()).toContainEqual(expect.objectContaining({
    country: 'Ireland',
    alpha_two_code: 'IE',
  }));
});

test('Create a new user', async ({ request, extraHTTPHeaders }) => {
  const newUser = await request.post(`https://reqres.in/api/users`, {
    headers: {      
      'Content-Type': 'application/json',
      'Accept': 'application/json; charset=UTF-8',
    },
    data: {
      name: 'morpheus',
      job: 'leader',
    }
  },);
  expect(newUser.status()).toBe(201);
  expect(newUser.ok()).toBeTruthy();  
  const bodyHex = await newUser.body();
  const body = hexToString(bodyHex);
  console.log(body);
  const bodyJson = JSON.parse(body);
  expect(bodyJson.name).toBe('morpheus');
  expect(bodyJson.job).toBe('leader');
  
});

function hexToString(str)
{
    const buf = Buffer.from(str, 'hex');
    return buf.toString('utf8');
}