const {test,expect} = require('@playwright/test');
const {EYPoManager} = require('../../pageobjects/EYPoManager');
const { D365LandingPage } = require('../../pageobjects/D365LandingPage');
const dataset = JSON.parse(JSON.stringify(require("../../testdata/Dynamics365/testdata.json")));

let eYPoManager
let d365LandingPage

test.beforeAll( async ({page}) => {
  
  eYPoManager = new EYPoManager(page);  
  d365LandingPage = eYPoManager.getD365LandingPage();
  })

  test.describe("User Story 0003 - Dynamics 365 page", () =>{    
    
  test('0003 - Dynamics 365 page : Sales Hub - Verify contacts',async({page}) =>
{ 
    await d365LandingPage.navigateToD365PortalPage(dataset.D365Url);
     await d365LandingPage.login(dataset.Username, dataset.Password);
     await d365LandingPage.clickSalesHub();
     await d365LandingPage.clickContacts();
     await d365LandingPage.clickMyActiveContacts();
     await d365LandingPage.clickAllContacts();    
     await d365LandingPage.searchContacts(dataset.fullName);
     await d365LandingPage.verifyResults(dataset.fullName, dataset.email, dataset.companyName, dataset.businessPhone, dataset.status);
 });
})


 
  
  
 


